let hours = document.querySelector(".hours"),
    minutes = document.querySelector(".minutes"),
    h = document.querySelector(".h"),
    m = document.querySelector(".m"),
    s = document.querySelector(".s")

function clock() {

    let time = new Date(),
        hour = new Date().getHours(),
        minut = new Date().getMinutes(),
        secund = new Date().getSeconds()

    hours.textContent = hour
    minutes.textContent = minut

    if (hour < 10) {
        hours.textContent = `0${hour}`
    } else {
        hours.textContent = hour
    }

    if (minut < 10) {
        minutes.textContent = `0${minut}`
    } else {
        minutes.textContent = minut
    }



    s.style.transform = `rotate(${secund * 6}deg)`
    m.style.transform = `rotate(${minut * 6}deg)`
    h.style.transform = `rotate(${hour * 30}deg)`


    setTimeout(() => {
        clock()
    }, 1000)
}

clock()

let tabsItem = [...document.querySelectorAll(".tabsItem")],
    tabsContentItem = [...document.querySelectorAll(".tabsContentItem")]

tabsItem.forEach((item, i) => {
    item.addEventListener("click", () => {

        if (i == 0) {
            tabsItem[0].classList.add("active")
            tabsItem[1].classList.remove("active")
            tabsContentItem[0].classList.add("active")
            tabsContentItem[1].classList.remove("active")

        } else {

            tabsItem[1].classList.add("active")
            tabsItem[0].classList.remove("active")
            tabsContentItem[1].classList.add("active")
            tabsContentItem[0].classList.remove("active")
        }

    })


});


let stopwatchMinutes = document.querySelector(".stopwatch__minutes"),
    stopwatchSeconds = document.querySelector(".stopwatch__seconds"),
    stopwatchMseconds = document.querySelector(".stopwatch__mseconds"),
    stopwatchBtn = document.querySelector(".stopwatch__btn"),
    span = document.querySelector(".tabsLink__span")


let stop;

function Watchtimer() {

    stop = setTimeout(() => {
        stopwatchMseconds.textContent++
        Watchtimer()

        if (stopwatchMseconds.textContent == 59) {
            stopwatchSeconds.textContent++
            stopwatchMseconds.textContent = 0
        }

        if (stopwatchSeconds.textContent == 59) {
            stopwatchMinutes.textContent++
            stopwatchSeconds.textContent = 0
        }

    }, 10)

}



stopwatchBtn.addEventListener("click", () => {
    if (stopwatchBtn.textContent == "start") {
        stopwatchBtn.textContent = "stop"
        Watchtimer()
        span.classList.add("active")

    } else if (stopwatchBtn.textContent == "stop") {
        stopwatchBtn.textContent = "clear"
        clearInterval(stop)
        span.classList.add("active_clear")
    } else {
        stopwatchBtn.textContent = "start"
        stopwatchMseconds.textContent = 0
        stopwatchSeconds.textContent = 0
        stopwatchMinutes.textContent = 0
        span.classList.remove("active")
        span.classList.remove("active_clear")


    }
})
